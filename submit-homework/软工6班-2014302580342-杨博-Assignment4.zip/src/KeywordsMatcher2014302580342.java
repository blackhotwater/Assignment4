import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class KeywordsMatcher2014302580342 {
	private ArrayList<SearchResult2014302580342> searchResultList= new  ArrayList<SearchResult2014302580342>();
	
	public ArrayList<SearchResult2014302580342> getSearchResultList(){
		return searchResultList;
	}
	
	public void getProfecessorInfo(){
		DataReader2014302580342 dr = new DataReader2014302580342();
		ArrayList<ProfessorInfo2014302580342> dataList = dr.getData();
		for(ProfessorInfo2014302580342 data:dataList){
			SearchResult2014302580342 result = new SearchResult2014302580342();
			result.setPi(data);
			result.setTf(0);
			searchResultList.add(result);
		}
		
	}
	
	public int getNumOfKeyword(String keyword,String target){
		int cnt = 0;
		String words[] = target.split(" ");
		for(String word:words){
			if(word.indexOf(keyword)!= -1)
				cnt++;
		}
		return cnt;
	}
	
	public void calcTF(String keyword){
		getProfecessorInfo();
		int tf = 0;
		for(SearchResult2014302580342 result:searchResultList){
			
			tf = getNumOfKeyword(keyword,result.getPi().getName())+
				 getNumOfKeyword(keyword,result.getPi().getEducationBackground())+
				 getNumOfKeyword(keyword,result.getPi().getResearchInterests())+
				 getNumOfKeyword(keyword,result.getPi().getEmail())+
				 getNumOfKeyword(keyword,result.getPi().getPhone());
			result.setTf(tf);
		}
	
	}
	class SortByTF implements Comparator<Object>{     
		public int compare(Object obj1,Object obj2){     
			SearchResult2014302580342 point1=(SearchResult2014302580342)obj1;     
			SearchResult2014302580342 point2=(SearchResult2014302580342)obj2;     
		  if(point1.getTf()<point2.getTf())     
		   return 1;     
		  else if (point1.getTf() == point2.getTf())    
		   return 0;     
		  else
		   return -1;
		}  
	}	

	public void sort(){
		 Collections.sort(searchResultList,new SortByTF());
	}
	
}
