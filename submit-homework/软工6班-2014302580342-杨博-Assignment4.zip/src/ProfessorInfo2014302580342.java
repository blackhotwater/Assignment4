
public class ProfessorInfo2014302580342 {
	private String name;
	private String educationBackground;
	private String researchInterests;
	private String email;
	private String phone;
	ProfessorInfo2014302580342(String Name,String EducationBackground,String ResearchInterests,String Email,String Phone){
		name = Name;
		educationBackground = EducationBackground;
		researchInterests=ResearchInterests;
		email = Email;
		phone = Phone;
	}
	public String getName(){
		return name;
	}
	public String getEducationBackground(){
		return educationBackground;
	}
	public String getResearchInterests(){
		return researchInterests;
	}
	public String getEmail(){
		return email;
	}
	public String getPhone(){
		return phone;
	}
	public void setName(String a){
		this.name = a;
	}
	public void setEducationBackground(String a){
		this.educationBackground = a;
	}
	public void setResearchInterests(String a){
		this.researchInterests = a;
	}
	public void setEmail(String a){
		this.email = a;
	}
	public void setPhone(String a){
		this.phone = a;
	}

}
