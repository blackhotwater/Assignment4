
public class SearchResult2014302580342 {
	private ProfessorInfo2014302580342 proInfo;
	private double tf;
	public void setPi(ProfessorInfo2014302580342 pro){
		proInfo = pro;
	}
	public void setTf(double TF){
		tf = TF;
	}
	public double getTf(){
		return tf;
	}
	public ProfessorInfo2014302580342 getPi(){
		return proInfo;
	}
}
