import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DataReader2014302580342 {
	
	private static String url = "jdbc:mysql://127.0.0.1:3306/my_schema?"+
	"user=root&password=123456";
	private static Connection getConnection(String url) {
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(url);
			return conn;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	public ArrayList<ProfessorInfo2014302580342> getData(){
		ArrayList<ProfessorInfo2014302580342>  dataList = new ArrayList<ProfessorInfo2014302580342>();
		
		Connection conn = getConnection(url);
		String sql = "select * from 2014302580342_professor_info";
		PreparedStatement pstmt;
		  try {
			pstmt = (PreparedStatement)conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			for(int i=1;i<26;i++){
				ProfessorInfo2014302580342 onerow  = 
						new ProfessorInfo2014302580342(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
				dataList.add(onerow);
				rs.next();
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return dataList;
	}
	
}
