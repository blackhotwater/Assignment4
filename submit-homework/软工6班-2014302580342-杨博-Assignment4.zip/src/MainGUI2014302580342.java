import java.awt.Font;
import java.awt.event.*;
import javax.swing.*;

@SuppressWarnings("serial")
public class MainGUI2014302580342 extends JFrame {
	 private JLabel jLabel;
	//������
	 public static void main(String[] args) {
		 MainGUI2014302580342 gui = new MainGUI2014302580342();
		 gui.setVisible(true);
	 }

	 MainGUI2014302580342(){
		 super();
		   setSize(400, 530);
		   getContentPane().setLayout(null);
		   add(getJLabel(), null);
		   //�����
		   JTextField jTextField = new JTextField();
			jTextField.setBounds(10, 10, 250, 40);
			getContentPane().add(jTextField);
			jTextField.setColumns(10);
		   //�����
		   JTextArea jTextArea= new JTextArea();
		   jTextArea.setBounds(10, 70, 365, 390);
		   jTextArea.setEditable(false);
		   jTextArea.setFont(new Font("΢���ź�",0,15));
		   JScrollPane ScrollPane1 = new JScrollPane(jTextArea,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		   jTextArea.setLineWrap(true);
		   ScrollPane1.setBounds(10, 70, 365, 400); 
		   getContentPane().add(ScrollPane1);
		   //��ť
		   JButton jButton = new JButton("Search");
		   jButton.setBounds(270, 10, 100, 40);
			jButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) 
				{
					jTextArea.setText("");
					KeywordsMatcher2014302580342 km=new KeywordsMatcher2014302580342();
					String text=jTextField.getText().trim();
					km.calcTF(text);
					km.sort();
					for(int i=0;i<km.getSearchResultList().size();i++)
					{
						if(km.getSearchResultList().get(i).getTf()>0){
							ProfessorInfo2014302580342 proInfo=km.getSearchResultList().get(i).getPi();
						    jTextArea.append(proInfo.getName()+"\n");
						    jTextArea.append(" \n");
						    jTextArea.append(proInfo.getEducationBackground()+"\n");
						    jTextArea.append(proInfo.getResearchInterests()+"\n");
							jTextArea.append(proInfo.getEmail()+"\n");
						    jTextArea.append(proInfo.getPhone()+"\n");
						    jTextArea.append(" \n");
						    jTextArea.append(" \n");
						}
					}
				}
			});
			getContentPane().add(jButton);
	 }
	 
	 private javax.swing.JLabel getJLabel() {
		   if(jLabel == null) {
		      jLabel = new javax.swing.JLabel();
		      jLabel.setBounds(300, 300, 300, 30);
		   }
		   return jLabel;
		}
 
}
